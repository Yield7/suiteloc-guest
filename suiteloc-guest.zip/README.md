# Suite Loc — Guest App

Prototype React + Vite + Tailwind. Inclut : Check‑in en ligne, Menu F&B (quantités avec ±), Services, Répertoire et Panier.

## Dev
```bash
npm i
npm run dev
```

## Build
```bash
npm run build
```

Déployable sur Vercel/Netlify/Cloudflare. Dossier build : `dist/`.
